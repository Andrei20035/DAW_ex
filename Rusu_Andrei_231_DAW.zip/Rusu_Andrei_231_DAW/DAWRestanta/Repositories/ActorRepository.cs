﻿using DAWRestanta.Data;
using DAWRestanta.Models;
using Microsoft.EntityFrameworkCore;


namespace DAWRestanta.Repositories
{
    public class ActorRepository : IActorRepository
    {
        private readonly AppDbContext _context;

        public ActorRepository(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Actor>> GetActorsByMovieId(int movieId)
        {
            return await _context.Actors.Where(a => a.Movies.Any(m => m.Id == movieId)).ToListAsync();
        }

        public async Task<List<Actor>> GetAllActors()
        {
            return await _context.Actors.ToListAsync();
        }

        public async Task AssignMovieToActor(int actorId, int movieId)
        {
            var actor = await _context.Actors.FindAsync(actorId);
            var movie = await _context.Movies.FindAsync(movieId);

            if (actor != null && movie != null)
            {
                actor.Movies.Add(movie);
                await _context.SaveChangesAsync();
            }
        }
    }
}
