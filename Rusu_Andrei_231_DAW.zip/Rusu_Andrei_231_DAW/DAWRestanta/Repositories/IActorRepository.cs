﻿using DAWRestanta.Models;

namespace DAWRestanta.Repositories
{
    public interface IActorRepository
    {
        Task<List<Actor>> GetActorsByMovieId(int movieId);
        Task<List<Actor>> GetAllActors();
        Task AssignMovieToActor(int actorId, int movieId);
    }
}
