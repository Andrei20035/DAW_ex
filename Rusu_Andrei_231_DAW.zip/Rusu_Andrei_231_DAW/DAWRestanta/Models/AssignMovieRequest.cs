﻿namespace DAWRestanta.Models
{
    public class AssignMovieRequest
    {
        public int ActorId { get; set; }
        public int MovieId { get; set; }
    }
}
