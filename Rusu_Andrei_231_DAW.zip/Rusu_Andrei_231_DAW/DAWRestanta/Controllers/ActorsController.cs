﻿using DAWRestanta.Models;
using DAWRestanta.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace DAWRestanta.Controllers
{

    [Route("api/[controller]")]
    [ApiController]
    public class ActorsController : ControllerBase
    {
        private readonly IActorRepository _actorRepository;

        public ActorsController(IActorRepository actorRepository)
        {
            _actorRepository = actorRepository;
        }

        [HttpGet("byMovie/{movieId}")]
        public async Task<ActionResult<List<Actor>>> GetActorsByMovie(int movieId)
        {
            var actors = await _actorRepository.GetActorsByMovieId(movieId);
            return Ok(actors);
        }

        [HttpGet]
        public async Task<ActionResult<List<Actor>>> GetAllActors()
        {
            var actors = await _actorRepository.GetAllActors();
            return Ok(actors);
        }

        [HttpPost("assignMovie")]
        public async Task<ActionResult> AssignMovieToActor([FromBody] AssignMovieRequest request)
        {
            await _actorRepository.AssignMovieToActor(request.ActorId, request.MovieId);
            return Ok();
        }
    }

}
